#!/bin/bash
set -e

version="19.03.12"
echo "https://download.docker.com/linux/static/stable/x86_64/docker-$version.tgz";
